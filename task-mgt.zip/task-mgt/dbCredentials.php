<?php
// Define database connection parameters
$hostname = "13.41.157.237"; // replace with your hostname
$username = "ubuntu"; // replace with your username
$password = ""; // replace with your password
$dbname = "taskmanagement"; // replace with your database name


// Create connection
$conn = mysqli_connect($hostname , $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>