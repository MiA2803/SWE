<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbCredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $taskName = $_POST["task-name"]; 
    $dueDate= $_POST["due-date"];	
    $timeDue= $_POST["time-due"];
    $priorityStatus= $_POST["priority-status"];	

    // Prepare an SQL statement
    $sql = "INSERT INTO Task (task_name, due_date, time_due, priority_status) VALUES ('$taskName','$dueDate','$timeDue','$priorityStatus')";
  
    // Execute the SQL statement
    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully :)";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  }
  
  // Close the database connection
  mysqli_close($conn);
  ?>


?>