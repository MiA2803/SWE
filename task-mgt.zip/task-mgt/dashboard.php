<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbCredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Select data from table
$sql = "SELECT * FROM Task";
$result = mysqli_query($conn, $sql);
$tasks = mysqli_fetch_all($result, MYSQLI_ASSOC);
//var_dump($crops);



// Create a PDO object to connect to the database
$pdo = new PDO('mysql:host=localhost;dbname=taskManagement', 'root', '');


// Prepare the query
$stmt = $pdo->prepare('SELECT COUNT(*) as total_tasks FROM Task');

// Execute the query
$stmt->execute();

// Fetch the result
$result = $stmt->fetch();

// Get the total number of tasks from the result
$totalTasks = $result['total_tasks'];
?>



<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://kit.fontawesome.com/2ac6a790f8.js" crossorigin="anonymous"></script>
</head>
<body>
	
	<div class="sidebar">
		<img class=logo src="images/logo.png">
		<ul>
			<li><i class="fa-solid fa-gauge"></i>
				<a href="dashboard.php">Dashboard</a>
			</li>
			<br>
			<br>
			
			<li>
				<i class="fa-solid fa-plus"></i>
				<a href="#" id="add-task-button">New Task</a>

					<div id="task-form" class="task-form" >
					<form method="POST" action="task_edit.php">
						<label for="task-name">Task Name:</label>
						<input type="text" id="task-name" name="task-name"><br><br>

						<label for="due-date">Due Date:</label>
						<input type="date" id="due-date" name="due-date"><br><br>

						<label for="time-due">Time Due:</label>
						<input type="time" id="time-due" name="time-due"><br><br>

						<label for="priority-status">Priority Status:</label>
						<select id="priority-status" name="priority-status">
						<option value="low">Low</option>
						<option value="medium">Medium</option>
						<option value="high">High</option>
						</select><br><br>
						<input type="submit" value="Add Task">
					</form>
					</div>
			</li>


			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<li>
				<i class="fa-solid fa-arrow-right-from-bracket"></i>
				<a href="login.php"> logout</a>
			</li>




		</ul>
	</div>
	<div class="content">
		<h1>Dashboard</h1>
		<div class="tiles">
			<div class="tile">
				<i class="fa-solid fa-check-to-slot"></i>
				<h2>Tasks Left to Do</h2>
				<h1></h1>
			</div>
		
		<div class="tile">
			<i class="fa-solid fa-timer"></i>
			<h2>Tasks in Progress</h2>
			<h1></h1>
			<div class="progress-bar">
				<div class="progress"></div>
			</div>
		</div>

			<div class="tile">
				<i class="fa-sharp fa-regular fa-timer"></i>
				<h2>Total Number of Tasks</h2>
				<h1><?php echo $totalTasks;?></h1>
			</div>
		</div>
		<div class="task-list">
			<p id="big-task">Tasks To do:</p>
			

			<?php
				foreach($tasks  as $task):
			?>
			<ul>
				<li>
					<input type="checkbox" id="task1" data-date="2023-05-07" data-time="14:00">
					<label for="task1">
						<span class="status"><?php echo $task["task_name"];?></span>
						<span class="due-date-time">Due on <span class="due-date"><?php echo $task["due_date"];?></span> at <span class="due-time"><?php echo $task["time_due"];?></span></span>
					</label>
				</li>
				<br>
				<br>

			</ul>
			<?php
				endforeach;
			?>
		</div>
		
	</div>
	<script>
		// Get the button that opens the form
	var addTaskButton = document.getElementById("add-task-button");

	// Get the form
	var taskForm = document.getElementById("task-form");

	// When the user clicks on the button, open the form
	addTaskButton.onclick = function() {
	taskForm.style.display = "block";
	}

	// When the user clicks anywhere outside of the form, close it
	window.onclick = function(event) {
	if (event.target == taskForm) {
		taskForm.style.display = "none";
	}
	}

	// Update count of completed tasks
	const checkboxes = document.querySelectorAll('input[type="checkbox"]');
	const countElement = document.querySelector('.tile h1');
	countElement.textContent = checkboxes.length - document.querySelectorAll('input[type="checkbox"]:checked').length;
	checkboxes.forEach(checkbox => {
	checkbox.addEventListener('change', event => {
		const completedCount = document.querySelectorAll('input[type="checkbox"]:checked').length;
		countElement.textContent = checkboxes.length - completedCount;
	});
});
	</script>


<script>
	// Get all the task checkboxes
const checkboxes2 = document.querySelectorAll('input[type="checkbox"]');

// Loop through each checkbox
checkboxes2.forEach(checkbox => {
  // Get the due date and time of the task
  const date = checkbox.dataset.date;
  const time = checkbox.dataset.time;

  // Convert the due date and time to a JavaScript Date object
  const dueDate = new Date(`${date} ${time}`);

  // Set up a timer to check if the due date and time have been reached
  setInterval(() => {
    const now = new Date();
    if (now >= dueDate) {
      // Display a notification
      alert(`Task "${checkbox.nextElementSibling.textContent.trim()}" is due now!`);
    }
  }, 1000); // Check every second
});

</script>
</body>
</html>
