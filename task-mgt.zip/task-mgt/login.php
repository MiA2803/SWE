<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "dbCredentials.php";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve the entered username and password
  $name = $_POST["name"];
  $password = $_POST["password"];

 
  // Query the skaiDBMS database for a matching username and hashed password
  $sql = "SELECT * FROM users WHERE name='$name'";
  $result = $conn->query($sql);

  // If a match is found, verify the hashed password and redirect to the dashboard page
  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row["password"])) {
      $_SESSION['loggedin'] = true;
      header("Location: dashboard.php");
      exit;
    } else {
      echo '<script>showAlert("Invalid username or password.");</script>';

    }
  } else {
    // If not, display an error message
    echo '<script>showAlert("Invalid username or password.");</script>';
  }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login Page</title>
  <link rel="stylesheet" href="login.css">

  </head>
<body>
  <div class="login-box">
    <img src="images/logother.png" class="logoligi2">
    <h2>Login</h2>
    <form name="loginForm" onsubmit="return validateForm()" method="POST" action="">
      <div class="user-box">
        <input type="text" name="name" required="">
        <label>Name</label>
      </div>
      <div class="user-box">
        <input type="password" name="password" required="">
        <label>Password</label>
      </div>
      <a href="#">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <button class="SUB" type="submit">Submit</button>
        <a href="signUp.php"><p class="signup" id="signUp-link">No account? sign up here</p></a>
      </a>
    </form>
  </div>
</body>
</html>

