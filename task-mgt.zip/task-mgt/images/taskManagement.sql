-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 02, 2023 at 10:19 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taskManagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `Task`
--

CREATE TABLE `Task` (
  `task_name` varchar(100) NOT NULL,
  `due_date` date NOT NULL,
  `time_due` time(4) NOT NULL,
  `priority_status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Task`
--

INSERT INTO `Task` (`task_name`, `due_date`, `time_due`, `priority_status`) VALUES
('Call Mum', '2023-05-26', '21:52:00.0000', 'high'),
('Wash Hair', '2023-05-11', '19:32:00.0000', 'high'),
('Pick Mimi From school', '2023-05-18', '15:34:00.0000', 'medium'),
('Take Laundry out', '2023-05-27', '18:02:00.0000', 'low'),
('Finish Assignment', '2023-05-18', '18:21:00.0000', 'high'),
('Submit CV to Dr. Issah', '2023-05-11', '06:48:00.0000', 'high'),
('Submit Textbook to Library', '2023-05-02', '18:52:00.0000', 'high'),
('Quit Smoking', '2023-05-14', '08:10:00.0000', 'high');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `password`) VALUES
('Nkunim Adu-Sarkodee', 'emmanuel.sarkodee@ashesi.edu.gh', '$2y$10$haLFBi1LZcEZ3AfH1k6T8.oQgQV8rAjBVHB5QzHGy46WIcm9tpWo6'),
('Miriam', 'Miriam@gmail.com', '$2y$10$ZMLYvvgCTSPg2nsDbzgHQ.DkwCnhmIcH1BmbEMk9r7iD8GlXroVNe'),
('Catherine Adu-Sarkodee', 'cathy@gmail.com', '$2y$10$XBvxNhgf0NxGDehudDMhq.9jDoz1Cj.rVNpA0BXRkjdCaA480.yA2');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
